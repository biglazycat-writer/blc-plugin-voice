export const apiVersion: 1;
export const apiRevision: 5;
export { PluginError, waitForTask, readDocument } from './helpers.js';
export type { WaitOptions, TaskWaitOptions, ExportedDocument } from './helpers.js';
export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export interface InvocationContext {
  source: string; workspaceId?: string; workspaceSession?: string; windowId?: string;
  editorId?: string; documentId?: string; revision?: string; selection?: string;
  sessionId?: string; resource?: string;
}
export interface Invocation extends InvocationContext {
  signal: AbortSignal; invocationId: string; taskId?: string;
  progress(value: number, message?: string): Promise<void>;
}
export interface DocumentTarget { workspaceId: string; workspaceSession: string; documentId: string; editorId: string; windowId?: string }
/** API 1 revision 3. Opens a creation document in the main window, without requiring a live editor. */
export interface DocumentNavigationTarget { workspaceId: string; workspaceSession: string; documentId: string }
export interface DocumentSnapshot extends DocumentTarget { content: string; format: 'markdown' | 'tiptap'; formatVersion?: 1; revision: string; draftHash: string; dirty: boolean }
export type DocumentExportChunk = { exportId: string; format: 'markdown'; formatVersion: 1; chunk: string; offset: number; nextOffset: number; totalBytes: number; hash: string; revision: string; draftHash: string; dirty: boolean };
export type WorkspaceRecord = { id: string; rootPath: string; title: string; createdAt: string; lastOpenedAt: string };
export type ServiceInfo = { pluginId: string; service: { id: string; version: string; methods: string[] }; available: boolean };
export type ResourceEntry = { Rel: string; Parent: string; Name: string; Title: string; Kind: string; Editable: boolean; Ext: string; IsDir: boolean; Size: number; ModTimeUnix: number; Hash: string; HashOmitted: boolean };
export type ResourcePage = { items: ResourceEntry[]; total: number; nextOffset: number };
export type ResourceText = { path: string; content: string; hash: string; offset: number; nextOffset: number; totalBytes: number; complete: boolean };
export interface DocumentChange extends DocumentTarget { operationId: string; revision: string; draftHash: string; content: string }
export interface Operation { operationId: string; state: 'pending' | 'completed' | 'failed' | 'uncertain'; result?: Json; error?: string }
export interface ResourceRequest { workspaceId: string; workspaceSession: string; path?: string; query?: string; offset?: number; limit?: number; content?: string; expectedHash?: string; operationId?: string }
export interface Resource { path: string; name: string; kind: string; size?: number }
export interface Task { id: string; pluginId: string; version: string; generation: string; command: string; context: InvocationContext; state: 'waiting'|'running'|'cancelling'|'completed'|'failed'|'cancelled'|'interrupted'|'uncertain'; progress: number; hasResult: boolean; result?: Json; error?: string; errorCode?: string }
export interface ViewOptions { location?: 'tab'|'panel'|'window'; context?: InvocationContext; state?: Json; instanceId?: string }
export interface ViewSession { pluginId: string; viewId: string; instanceId: string; title: string; location: string; context: InvocationContext; state?: Json; dirty: boolean; connected: boolean; theme?: Record<string,string>; colorScheme: ColorScheme; uiReady: boolean; timings?: Record<string, number> }
export interface SharedAPI {
  images: { list(request?: {query?:string;offset?:number;limit?:number;workspaceId?:string;workspaceSession?:string}): Promise<{items:{id:string;name:string;src:string;width:number;height:number}[];total:number}>; read(request:{src:string;offset?:number;limit?:number;hash?:string;workspaceId?:string;workspaceSession?:string}): Promise<{chunk:string;total:number;hash:string}> };
  workspace: { list(): Promise<WorkspaceRecord[]>; resources(request: ResourceRequest): Promise<ResourcePage>; read(request: ResourceRequest): Promise<ResourceText>; search(request: ResourceRequest): Promise<ResourcePage>; import(request: ResourceRequest): Promise<Operation> };
  documents: { snapshot(target: DocumentTarget): Promise<DocumentSnapshot>; export(request: DocumentTarget & { exportId?: string; offset?: number; limit?: number }): Promise<DocumentExportChunk>; apply(change: DocumentChange): Promise<Operation>; operation(operationId: string): Promise<Operation> };
  storage: { get(key: string, workspaceId?: string): Promise<Json>; set(key: string, value: Json, workspaceId?: string): Promise<void> };
  views: { open(view: string, options?: ViewOptions): Promise<ViewSession> };
  ui: { notify(message: string): Promise<void>; openFile(options?: Json): Promise<string>; saveFile(options?: Json): Promise<string>; openExternal(url: string): Promise<void>; openDocument(target: DocumentNavigationTarget): Promise<void> };
}
export interface PluginContext extends SharedAPI {
  apiVersion: 1; apiRevision: number; pluginId: string; generation: string; dataDir: string;
  views: SharedAPI['views'] & { close(instanceId: string): Promise<void> };
  commands: { register(id: string, handler: (args: any, invocation: Invocation) => unknown | Promise<unknown>): void };
  services: { provide(id: string, methods: Record<string,(args: any, invocation: Invocation) => unknown|Promise<unknown>>): void; call(plugin: string, service: string, method: string, args: Json, invocation?: Invocation): Promise<Json>; list(): Promise<ServiceInfo[]> };
  events: { on(name: string, handler: (event: {id:string;name:string;workspaceId:string;payload:Json}, context: {signal:AbortSignal}) => void|Promise<void>): void; emit(name: string, payload: Json): Promise<void> };
  credentials: { get(key: string): Promise<string|null>; set(key: string, value: string): Promise<void>; delete(key: string): Promise<void> };
  ai: {
    run(request: { conversationId: string; text: string }): Promise<Json>;
    /** API 1 revision 5. Enabled platform text models; no API keys or URLs. */
    models(): Promise<AIModel[]>;
    /** API 1 revision 5. Uses the platform model gateway; no Agent conversation. */
    generate(request: AIGenerateRequest, options?: {signal?: AbortSignal}): Promise<AIGenerateResponse>;
  };
}
export interface AIModel { id: string; name: string; isDefault: boolean }
export interface AIGenerateRequest { prompt: string; systemPrompt?: string; modelId?: string; maxTokens?: number }
export interface AIGenerateResponse { text: string; modelId: string; model: string; provider: string; requestId: string }
export function definePlugin(activate: (context: PluginContext) => void | (() => void | Promise<void>) | Promise<void | (() => void | Promise<void>)>): { activate: typeof activate };

/** Resolved host appearance; independent of document/export themes. */
export type ColorScheme = 'light' | 'dark';

/** API 1 revision 4: provider contracts used by desktop product features. */
export type ProviderContract = 'export.text' | 'ocr' | 'speech.tts';
export interface ProviderContribution { id: string; contract: ProviderContract; version: 1; service: string }
/** Base64 bytes, with UTF-8 byte offsets for JSON; SHA-256 covers the full bytes. */
export interface ProviderByteChunk { chunk: string; nextOffset: number; total: number; hash: string; complete: boolean }
export interface OCRProviderResult { content: string; format: 'text' | 'markdown' }
export interface OCRProviderService {
  put(args: {id: string; index: number; chunk: string}, invocation: Invocation): unknown;
  finish(args: {id: string}, invocation: Invocation): unknown;
  start(args: {transferId: string; format: 'text' | 'markdown'; source?: string}, invocation: Invocation): {jobId: string} | Promise<{jobId: string}>;
  status(args: {jobId: string}, invocation: Invocation): {state: 'waiting' | 'running' | 'completed' | 'failed' | 'cancelled'; progress?: number; error?: string; errorCode?: string} | Promise<{state: 'waiting' | 'running' | 'completed' | 'failed' | 'cancelled'; progress?: number; error?: string; errorCode?: string}>;
  result(args: {jobId: string; offset: number; limit: number}, invocation: Invocation): ProviderByteChunk | Promise<ProviderByteChunk>;
  cancel(args: {jobId: string}, invocation: Invocation): unknown;
  release(args: {transferId?: string; jobId?: string}, invocation: Invocation): unknown;
}
export interface SpeechProviderService {
  voices(args: {}, invocation: Invocation): {voices: {id: string; name: string; language?: string}[]} | Promise<{voices: {id: string; name: string; language?: string}[]}>;
  synthesize(args: {text: string; voiceId?: string; speed?: number}, invocation: Invocation): {audioId: string; mimeType: 'audio/wav' | 'audio/mpeg'} | Promise<{audioId: string; mimeType: 'audio/wav' | 'audio/mpeg'}>;
  read(args: {audioId: string; offset: number; limit: number}, invocation: Invocation): ProviderByteChunk | Promise<ProviderByteChunk>;
  release(args: {audioId: string}, invocation: Invocation): unknown;
}
